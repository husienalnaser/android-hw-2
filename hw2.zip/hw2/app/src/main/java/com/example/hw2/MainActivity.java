package com.example.hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText x = findViewById(R.id.num1);
        final EditText y = findViewById(R.id.num2);
        final EditText z = findViewById(R.id.num3);
        final EditText q = findViewById(R.id.num4);
        Button b = findViewById(R.id.btn);
        final TextView t = findViewById(R.id.result);
        Button b2 = findViewById(R.id.btn2);
        final TextView t2 = findViewById(R.id.textView3);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a= Integer.parseInt(x.getText().toString());
                int b=  Integer.parseInt(y.getText().toString());
                int c=  Integer.parseInt(z.getText().toString());
                int d=  Integer.parseInt(q.getText().toString());
                int sum= a+b+c+d;

                t.setText(sum+" ");
                if (sum>100){
                    t.setText("invalid info");

                }
                 else if (sum<0){
                    t.setText("invalid info");
                }

//                else if (sum>=50){
//                    t2.setText("GOOD JOB");
//
//
//                }
//                else if (sum<50){
//                    t2.setText("TRY HARDER NEXT TIME");
//                }


            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                x.setText("");
                y.setText("");
                z.setText("");
                q.setText("");
                t.setText("result");
            }
        });

    }
}